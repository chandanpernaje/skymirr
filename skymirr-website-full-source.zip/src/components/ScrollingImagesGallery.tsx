import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ImageZoomModal } from './ImageZoomModal';
import {
  ArrowLeft,
  ArrowRight,
  Eye,
  ShieldCheck,
  Zap,
  Sparkles,
  Layers,
  Activity,
  Play,
  Pause,
  ChevronRight,
  ChevronLeft,
  CheckCircle2,
  Radio,
  Sliders,
  Maximize2,
  X,
  Compass,
  MoveHorizontal
} from 'lucide-react';

export interface GalleryItem {
  id: string;
  title: string;
  category: string;
  badge: string;
  image: string;
  tagline: string;
  highlight: string;
  specs: { label: string; value: string }[];
  description: string;
}

const GALLERY_ITEMS: GalleryItem[] = [
  {
    id: 'antennas-gallery',
    title: 'SkyBlade™ Ultra-Wideband Antennas',
    category: 'Antenna Systems',
    badge: 'Carrier Validated',
    image: '/images/antennas-new.jpg',
    tagline: 'Multi-layer coupling omnidirectional whip array covering 617 to 5925 MHz with stable azimuth radiation',
    highlight: '6.0 dBi Peak Gain · VSWR < 2.0:1',
    description: 'Engineered with proprietary MuLCAT® multi-layer coupling that eliminates destructive phase interference between adjacent cellular and Wi-Fi bands. Delivers sustained high-efficiency transmission across all 4G LTE, 5G NR (FR1), and Wi-Fi 6E/7 frequency allocations.',
    specs: [
      { label: 'Frequency Range', value: '617 – 5925 MHz' },
      { label: 'Peak Gain', value: '6.0 dBi' },
      { label: 'VSWR', value: '< 2.0:1 Typ.' },
      { label: 'Radiation Pattern', value: 'Omni 360° Azimuth' },
    ],
  },
  {
    id: 'routers-gallery',
    title: 'Sky5G™ CPE Wireless Router (TCPA-117)',
    category: 'Carrier Gateway',
    badge: 'CES® 2026 Honoree',
    image: '/images/5g-routers.jpg',
    tagline: 'Carrier-certified 5G Sub-6 & Wi-Fi 7 gateway with integrated MuLCAT® array for +42% cell-edge reach',
    highlight: 'T-Priority Ready · AT&T & T-Mobile Certified',
    description: 'High-speed fixed wireless access gateway designed for mission-critical enterprise failover, retail branch deployments, and first responder command centers. Powered by dual internal MuLCAT® antennas that extract clean signal from weak suburban and rural cell towers.',
    specs: [
      { label: 'Cellular Technology', value: '5G Sub-6 NSA/SA' },
      { label: 'Wi-Fi Standard', value: 'Wi-Fi 7 (802.11be)' },
      { label: 'Ethernet Ports', value: '2.5G WAN + 4x GbE LAN' },
      { label: 'Carrier Certs', value: 'AT&T, T-Mobile, PTCRB' },
    ],
  },
  {
    id: 'trackers-gallery',
    title: 'SkyTrack™ Industrial Asset Trackers',
    category: 'Industrial IoT',
    badge: 'ATEX Zone 2',
    image: '/images/asset-trackers.jpg',
    tagline: 'Ruggedized IP68 cellular GPS telemetry terminal with internally decoupled MuLCAT® micro-antennas',
    highlight: '7-Year Battery Life · Multi-Constellation GNSS',
    description: 'Ultra-low-power industrial sensor gateway providing real-time location, temperature, shock, and battery diagnostics for heavy equipment, rail cars, cold-chain cargo, and offshore energy infrastructure.',
    specs: [
      { label: 'Cellular Bands', value: 'LTE-M & NB-IoT Global' },
      { label: 'Ingress Protection', value: 'IP68 & MIL-STD-810H' },
      { label: 'Battery Capacity', value: 'Up to 7 Years Autonomous' },
      { label: 'Positioning', value: 'GPS, GLONASS, Galileo, BeiDou' },
    ],
  },
  {
    id: 'mimo-gallery',
    title: 'SkyBlade™ TAMP161 Broadband MIMO',
    category: 'Vehicle & Transit',
    badge: 'MIL-STD-810H',
    image: '/images/our-products.png',
    tagline: 'Dual cross-polarized omnidirectional antenna module engineered for emergency response & transport fleets',
    highlight: 'IP67 Submersible · High Shock & Vibration',
    description: 'Rugged low-profile aerodynamic rooftop antenna delivering simultaneous high-throughput cellular uplink and dual-band Wi-Fi connectivity for public safety vehicles, transit buses, and autonomous mobile robotics.',
    specs: [
      { label: 'Configuration', value: '4x4 MIMO Cellular + 2x2 Wi-Fi' },
      { label: 'Housing Grade', value: 'Impact Resistant Xenoy™' },
      { label: 'Submersion', value: 'IP67 Ingress Rated' },
      { label: 'Cable Length', value: 'Low-loss RG-58 / CFD200' },
    ],
  },
  {
    id: 'next-gen-gallery',
    title: 'Next-Gen MuLCAT® Multi-Resonance Arrays',
    category: 'Electromagnetic R&D',
    badge: 'Patent-Pending',
    image: '/images/skymirr-next-gen-antennas.jpg',
    tagline: 'Next-generation compact broadband modules prototyped in our Songdo Incheon 3D microwave chamber',
    highlight: 'Multi-Layer Constructive Resonance',
    description: 'Breakthrough electromagnetic topology utilizing tightly-spaced dielectric resonators that turn mutual coupling into constructive radiation power. Enables sub-miniature antenna form factors with octave bandwidths previously deemed impossible by the Chu-Harrington limit.',
    specs: [
      { label: 'Bandwidth Ratio', value: '10:1 Continuous' },
      { label: 'Efficiency Gain', value: '+65% over Dipoles' },
      { label: 'R&D Facility', value: 'Songdo 3D Anechoic Lab' },
      { label: 'Key Patent', value: 'Multi-Layer Reactive Coupling' },
    ],
  },
];

interface ScrollingImagesGalleryProps {
  onOpenQuote: (productName?: string) => void;
  onNavigate?: (page: string) => void;
}

export function ScrollingImagesGallery({ onOpenQuote, onNavigate }: ScrollingImagesGalleryProps) {
  const [activeIndex, setActiveIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [selectedItem, setSelectedItem] = useState<GalleryItem | null>(null);

  // Horizontal Scroll Carousel Ref & Mouse Dragging State
  const scrollTrackRef = useRef<HTMLDivElement | null>(null);
  const [isMouseDown, setIsMouseDown] = useState(false);
  const [startX, setStartX] = useState(0);
  const [scrollLeftState, setScrollLeftState] = useState(0);
  const touchStartXRef = useRef<number | null>(null);

  // Auto-advance if playing
  useEffect(() => {
    if (!isPlaying) return;
    const interval = setInterval(() => {
      setActiveIndex((prev) => {
        const next = (prev + 1) % GALLERY_ITEMS.length;
        scrollToCard(next);
        return next;
      });
    }, 4500);
    return () => clearInterval(interval);
  }, [isPlaying]);

  const scrollToCard = (index: number) => {
    if (scrollTrackRef.current) {
      const cardWidth = 280;
      scrollTrackRef.current.scrollTo({
        left: index * cardWidth,
        behavior: 'smooth',
      });
    }
  };

  const nextSlide = () => {
    const next = (activeIndex + 1) % GALLERY_ITEMS.length;
    setActiveIndex(next);
    scrollToCard(next);
  };

  const prevSlide = () => {
    const prev = (activeIndex - 1 + GALLERY_ITEMS.length) % GALLERY_ITEMS.length;
    setActiveIndex(prev);
    scrollToCard(prev);
  };

  const scrollTrack = (direction: 'left' | 'right') => {
    if (scrollTrackRef.current) {
      const offset = 300;
      scrollTrackRef.current.scrollBy({
        left: direction === 'left' ? -offset : offset,
        behavior: 'smooth',
      });
    }
  };

  // Drag-to-scroll handlers for desktop mouse
  const handleMouseDown = (e: React.MouseEvent) => {
    if (!scrollTrackRef.current) return;
    setIsMouseDown(true);
    setStartX(e.pageX - scrollTrackRef.current.offsetLeft);
    setScrollLeftState(scrollTrackRef.current.scrollLeft);
  };

  const handleMouseLeave = () => {
    setIsMouseDown(false);
  };

  const handleMouseUp = () => {
    setIsMouseDown(false);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isMouseDown || !scrollTrackRef.current) return;
    e.preventDefault();
    const x = e.pageX - scrollTrackRef.current.offsetLeft;
    const walk = (x - startX) * 1.5;
    scrollTrackRef.current.scrollLeft = scrollLeftState - walk;
  };

  // Touch handlers for mobile swipe
  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartXRef.current = e.touches[0].clientX;
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (touchStartXRef.current === null) return;
    const touchEndX = e.changedTouches[0].clientX;
    const diff = touchStartXRef.current - touchEndX;
    if (Math.abs(diff) > 40) {
      if (diff > 0) {
        nextSlide();
      } else {
        prevSlide();
      }
    }
    touchStartXRef.current = null;
  };

  const activeProduct = GALLERY_ITEMS[activeIndex];

  return (
    <section id="interactive-showcase" className="scroll-mt-20 py-20 sm:py-24 bg-[#070B14] relative overflow-hidden border-t border-slate-800 text-white">
      {/* Radiant High-Tech Ambient Glows */}
      <div className="pointer-events-none absolute -top-24 left-1/2 -translate-x-1/2 w-[900px] h-[400px] bg-blue-600/15 blur-[140px] rounded-full" />
      <div className="pointer-events-none absolute bottom-0 right-10 w-[500px] h-[350px] bg-cyan-500/10 blur-[120px] rounded-full" />
      <div className="pointer-events-none absolute inset-0 rf-grid-dense opacity-15" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
          className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-12"
        >
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/30 text-cyan-400 text-xs font-mono font-bold tracking-wider uppercase mb-3">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
              <span>Interactive Hardware Slider &amp; Spec Inspector</span>
            </div>
            <h2 className="text-2xl sm:text-4xl lg:text-5xl font-black font-['Poppins'] tracking-tight text-white uppercase leading-tight">
              CORE HARDWARE &amp; TECHNOLOGY SHOWCASE
            </h2>
            <p className="text-slate-300 text-sm sm:text-base mt-2 max-w-2xl leading-relaxed">
              Explore authentic SkyMirr carrier-grade antennas, 5G gateways, and IoT devices. Click, drag to scroll, or swipe to inspect verified RF specifications.
            </p>
          </div>

          {/* Slider Controls: Counter, Play/Pause, Next/Prev */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 bg-slate-900/80 border border-slate-800 rounded-xl px-3.5 py-2 font-mono text-xs text-slate-300">
              <span className="font-bold text-cyan-400">0{activeIndex + 1}</span>
              <span className="text-slate-600">/</span>
              <span>0{GALLERY_ITEMS.length}</span>
            </div>

            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className={`p-2.5 rounded-xl border transition-all cursor-pointer ${
                isPlaying
                  ? 'bg-cyan-500/20 border-cyan-400/50 text-cyan-300'
                  : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:text-white hover:border-slate-700'
              }`}
              title={isPlaying ? 'Pause Slideshow' : 'Play Slideshow'}
              aria-label={isPlaying ? 'Pause Slideshow' : 'Play Slideshow'}
            >
              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
            </button>

            <button
              onClick={prevSlide}
              className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800 text-slate-300 hover:text-white hover:border-cyan-400 hover:bg-slate-800 transition-all cursor-pointer active:scale-95 shadow-md shadow-black/40"
              aria-label="Previous hardware slide"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>

            <button
              onClick={nextSlide}
              className="p-2.5 rounded-xl bg-blue-600 border border-blue-500 text-white hover:bg-blue-500 transition-all cursor-pointer active:scale-95 shadow-lg shadow-blue-600/30"
              aria-label="Next hardware slide"
            >
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </motion.div>

        {/* Click-to-Move Category Tabs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="flex items-center gap-2 overflow-x-auto pb-3 mb-8 no-scrollbar"
        >
          {GALLERY_ITEMS.map((item, idx) => {
            const isActive = activeIndex === idx;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveIndex(idx);
                  scrollToCard(idx);
                }}
                className={`shrink-0 px-4 py-2 rounded-xl text-xs font-semibold font-['Poppins'] transition-all flex items-center gap-2 cursor-pointer border ${
                  isActive
                    ? 'bg-blue-600 border-cyan-400 text-white shadow-md shadow-blue-600/30 scale-102'
                    : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-800/80 hover:border-slate-700'
                }`}
              >
                <span className={`w-1.5 h-1.5 rounded-full ${isActive ? 'bg-cyan-300 animate-ping' : 'bg-slate-600'}`} />
                <span>{item.category}</span>
              </button>
            );
          })}
        </motion.div>

        {/* Featured Click-Move Active Display Card (Premium Desktop & Mobile Bento) */}
        <motion.div
          initial={{ opacity: 0, y: 35 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-40px' }}
          transition={{ duration: 0.65, ease: [0.22, 1, 0.36, 1] }}
          onTouchStart={handleTouchStart}
          onTouchEnd={handleTouchEnd}
          className="rounded-3xl bg-slate-900/90 border border-slate-800/90 p-5 sm:p-8 lg:p-10 shadow-2xl relative overflow-hidden transition-all duration-500"
        >
          {/* Subtle Accent Glow Ring */}
          <div className="pointer-events-none absolute -top-32 -right-32 w-96 h-96 bg-cyan-500/10 blur-[100px] rounded-full" />
          <div className="pointer-events-none absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-600 via-cyan-400 to-blue-600" />

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
            {/* Left: 100% Correctly Fitted Hardware Photography in High-Tech Studio Enclosure */}
            <div className="lg:col-span-6 flex flex-col items-center">
              <div className="w-full relative aspect-[16/11] sm:aspect-[16/10] rounded-2xl bg-gradient-to-b from-slate-950 via-[#0A101D] to-slate-950 border border-slate-800 p-4 sm:p-6 flex items-center justify-center overflow-hidden group shadow-inner">
                {/* Blueprint grid inside viewport */}
                <div className="absolute inset-0 rf-grid opacity-20 pointer-events-none" />

                {/* Subtle Radial Pedestal Glow behind hardware */}
                <div className="absolute w-48 h-48 sm:w-64 sm:h-64 rounded-full bg-cyan-500/15 blur-3xl pointer-events-none" />

                {/* The Unobstructed Hardware Image with 100% Fit */}
                <img
                  src={activeProduct.image}
                  alt={activeProduct.title}
                  key={activeProduct.image}
                  className="max-h-full max-w-full object-contain relative z-10 transition-all duration-500 filter drop-shadow-[0_15px_30px_rgba(0,0,0,0.7)] group-hover:scale-104 cursor-zoom-in"
                  onClick={() => setSelectedItem(activeProduct)}
                  loading="lazy"
                />

                {/* Floating Micro-Badges: Non-obstructive positioning */}
                <div className="absolute top-3 left-3 z-20">
                  <span className="px-2.5 py-1 rounded-lg text-[10px] font-mono font-bold uppercase tracking-wider bg-blue-600/90 text-cyan-200 border border-blue-400/40 shadow-sm backdrop-blur-xs">
                    {activeProduct.badge}
                  </span>
                </div>

                <div className="absolute top-3 right-3 z-20">
                  <button
                    onClick={() => setSelectedItem(activeProduct)}
                    className="p-2 rounded-lg bg-slate-900/80 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-white transition-all shadow-md cursor-pointer flex items-center gap-1.5 text-xs font-mono"
                    title="Enlarge & Inspect Details"
                  >
                    <Maximize2 className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline text-[10px]">Inspect</span>
                  </button>
                </div>

                {/* Bottom Hardware Tagline Bar */}
                <div className="absolute bottom-2.5 left-3 right-3 z-20 flex items-center justify-between pointer-events-none">
                  <span className="text-[10px] font-mono font-semibold text-slate-400 bg-slate-950/80 px-2 py-0.5 rounded border border-slate-800">
                    MuLCAT® Physical Layer
                  </span>
                  <span className="text-[10px] font-mono font-bold text-cyan-300 bg-slate-950/80 px-2 py-0.5 rounded border border-slate-800">
                    {activeProduct.highlight.split('·')[0]}
                  </span>
                </div>
              </div>

              {/* Quick Slide Dots Indicator */}
              <div className="flex items-center justify-center gap-2 mt-4 w-full">
                {GALLERY_ITEMS.map((item, idx) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActiveIndex(idx);
                      scrollToCard(idx);
                    }}
                    className={`h-1.5 rounded-full transition-all cursor-pointer ${
                      activeIndex === idx ? 'w-8 bg-cyan-400' : 'w-2 bg-slate-700 hover:bg-slate-500'
                    }`}
                    aria-label={`Go to slide ${idx + 1}`}
                  />
                ))}
              </div>
            </div>

            {/* Right: Technical Specifications & Commercial Inquiries */}
            <div className="lg:col-span-6 space-y-6">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-xs font-mono font-bold text-cyan-400 uppercase tracking-widest">
                    {activeProduct.category}
                  </span>
                  <span className="text-slate-600">·</span>
                  <span className="text-xs font-mono text-slate-400">SkyMirr Engineering Spec</span>
                </div>

                <h3 className="text-2xl sm:text-3xl font-extrabold text-white font-['Poppins'] tracking-tight">
                  {activeProduct.title}
                </h3>
                <p className="text-slate-300 text-xs sm:text-sm mt-3 leading-relaxed">
                  {activeProduct.description}
                </p>
              </div>

              {/* 4-Cell Engineering Specs Grid with Mobile Responsive Alignment */}
              <div className="grid grid-cols-2 gap-3 pt-2">
                {activeProduct.specs.map((spec, sIdx) => (
                  <div
                    key={sIdx}
                    className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/90 hover:border-cyan-500/40 transition-colors"
                  >
                    <span className="text-[10px] font-mono text-slate-400 uppercase block tracking-wider">
                      {spec.label}
                    </span>
                    <span className="text-xs sm:text-sm font-bold text-white font-mono mt-0.5 block truncate">
                      {spec.value}
                    </span>
                  </div>
                ))}
              </div>

              {/* Highlight Pill */}
              <div className="p-3.5 rounded-xl bg-gradient-to-r from-blue-950/70 to-slate-900 border border-blue-500/30 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span className="text-xs font-mono font-bold text-cyan-200">
                    {activeProduct.highlight}
                  </span>
                </div>
                <span className="text-[10px] font-mono uppercase text-slate-400 font-semibold shrink-0">
                  Carrier Grade
                </span>
              </div>

              {/* Call-to-Action Buttons */}
              <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
                <button
                  onClick={() => onOpenQuote(activeProduct.title)}
                  className="w-full sm:w-auto flex-1 py-3 px-6 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs font-['Poppins'] tracking-wider uppercase transition-all shadow-lg shadow-blue-600/30 flex items-center justify-center gap-2 cursor-pointer active:scale-98"
                >
                  <span>Request Engineering Datasheet</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                {onNavigate && (
                  <button
                    onClick={() => onNavigate('products')}
                    className="w-full sm:w-auto py-3 px-5 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700 text-slate-200 text-xs font-semibold font-['Poppins'] transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <span>View All Products</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          </div>
        </motion.div>

        {/* 100% Functional Drag-to-Scroll & Click-Move Horizontal Carousel Track */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-30px' }}
          transition={{ duration: 0.6 }}
          className="mt-10"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
              <MoveHorizontal className="w-4 h-4 text-cyan-400 animate-pulse" />
              <span>Scroll, drag, or click to move between hardware modules</span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => scrollTrack('left')}
                className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white hover:border-slate-700 transition-colors cursor-pointer"
                title="Scroll carousel left"
                aria-label="Scroll carousel left"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={() => scrollTrack('right')}
                className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white hover:border-slate-700 transition-colors cursor-pointer"
                title="Scroll carousel right"
                aria-label="Scroll carousel right"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div
            ref={scrollTrackRef}
            onMouseDown={handleMouseDown}
            onMouseLeave={handleMouseLeave}
            onMouseUp={handleMouseUp}
            onMouseMove={handleMouseMove}
            className={`flex gap-4 overflow-x-auto pb-4 pt-1 snap-x snap-mandatory scroll-smooth no-scrollbar ${
              isMouseDown ? 'cursor-grabbing select-none' : 'cursor-grab'
            }`}
          >
            {GALLERY_ITEMS.map((item, idx) => {
              const isCurrent = activeIndex === idx;
              return (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.45, delay: idx * 0.08 }}
                  whileHover={{ y: -3, transition: { duration: 0.2 } }}
                  onClick={() => {
                    setActiveIndex(idx);
                    scrollToCard(idx);
                  }}
                  className={`snap-start shrink-0 w-64 sm:w-72 rounded-2xl p-3.5 border transition-all duration-300 cursor-pointer flex flex-col justify-between relative overflow-hidden select-none ${
                    isCurrent
                      ? 'bg-slate-900 border-cyan-400 shadow-xl shadow-cyan-500/10 ring-2 ring-cyan-400/40 scale-102'
                      : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 hover:bg-slate-900/90'
                  }`}
                >
                  {/* Thumbnail Stage with 100% Fit */}
                  <div className="relative aspect-[16/11] w-full rounded-xl bg-slate-950/90 overflow-hidden flex items-center justify-center p-3 mb-2.5 border border-slate-800/80">
                    <img
                      src={item.image}
                      alt={item.title}
                      className="max-h-full max-w-full object-contain group-hover:scale-106 transition-transform duration-300 pointer-events-none"
                      loading="lazy"
                    />
                    {isCurrent && (
                      <div className="absolute top-2 right-2 w-2 h-2 rounded-full bg-cyan-400 animate-pulse shadow-sm shadow-cyan-400" />
                    )}
                  </div>

                  <div>
                    <span className="text-[10px] font-mono text-cyan-400 uppercase font-bold block truncate">
                      {item.category}
                    </span>
                    <h4 className="text-sm font-bold text-white font-['Poppins'] truncate mt-0.5">
                      {item.title.split('—')[0]}
                    </h4>
                    <div className="text-[11px] font-mono text-slate-400 mt-1 truncate">
                      {item.specs[0].value}
                    </div>
                  </div>

                  <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex items-center justify-between text-[10px] font-mono text-slate-400">
                    <span className={isCurrent ? 'text-cyan-300 font-bold' : ''}>
                      {isCurrent ? '● Active in Viewport' : 'Click to Focus'}
                    </span>
                    <ArrowRight className={`w-3.5 h-3.5 ${isCurrent ? 'text-cyan-300 translate-x-0.5' : 'text-slate-600'}`} />
                  </div>
                </motion.div>
              );
            })}
          </div>
        </motion.div>
      </div>

      {/* Lightbox Modal for Enlarge Image & Engineering Inspection with Zoom & Pan */}
      <ImageZoomModal
        isOpen={!!selectedItem}
        onClose={() => setSelectedItem(null)}
        imageSrc={selectedItem?.image || ''}
        title={selectedItem?.title || ''}
        subtitle={selectedItem?.category}
        specs={selectedItem?.specs}
        highlight={selectedItem?.highlight}
      />
    </section>
  );
}
