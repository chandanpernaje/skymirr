import { useState } from 'react';
import { motion } from 'framer-motion';
import { SKYMIRR_DATA } from '../data/skymirrData';
import { ArrowRight, CheckCircle2, ShieldCheck, ChevronRight, Sparkles, Layers, ZoomIn } from 'lucide-react';
import { ImageZoomModal } from './ImageZoomModal';

interface ProductCategoriesProps {
  onOpenQuote: (productName?: string) => void;
  onNavigate?: (page: string) => void;
}

export function ProductCategoriesSection({ onOpenQuote, onNavigate }: ProductCategoriesProps) {
  const [zoomModalData, setZoomModalData] = useState<{
    isOpen: boolean;
    imageSrc: string;
    title: string;
    subtitle?: string;
    specs?: { label: string; value: string }[];
    highlight?: string;
  }>({
    isOpen: false,
    imageSrc: '',
    title: '',
  });

  const openZoom = (
    imageSrc: string,
    title: string,
    subtitle?: string,
    specs?: { label: string; value: string }[],
    highlight?: string
  ) => {
    setZoomModalData({
      isOpen: true,
      imageSrc,
      title,
      subtitle,
      specs,
      highlight,
    });
  };

  return (
    <section id="products-grid" className="scroll-mt-20 py-20 sm:py-24 bg-[#F8FAFC] border-t border-slate-200 relative overflow-hidden">
      <div id="products-overview" className="absolute -top-24 pointer-events-none" />
      {/* Subtle ambient lighting */}
      <div className="pointer-events-none absolute top-10 left-1/2 -translate-x-1/2 w-[800px] h-[350px] bg-blue-500/5 blur-[120px] rounded-full" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
        {/* Section Header with Framer Motion Entrance Animation */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-60px' }}
          transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
          className="max-w-4xl mx-auto text-center mb-14 sm:mb-16"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 border border-blue-200/80 text-blue-700 text-xs font-mono font-bold tracking-wider uppercase mb-3">
            <Layers className="w-3.5 h-3.5 text-blue-600" />
            <span>Core Hardware Architecture</span>
          </div>
          <h2 className="text-2xl sm:text-4xl lg:text-5xl font-black text-slate-950 font-['Poppins'] tracking-tight uppercase leading-tight [text-wrap:balance]">
            WHEN IT HAS TO CONNECT, IT HAS TO BE SKYMIRR
          </h2>
          <p className="text-slate-600 text-sm sm:text-base mt-4 max-w-3xl mx-auto leading-relaxed [text-wrap:balance]">
            We develop/manufacture advanced RF technology-based products that better our lives, such as cost-effective, better performing, broadband wireless communications for everyone and medical applications that treat serious disease far more effectively.
          </p>

          <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
            <h3 className="text-xl sm:text-2xl font-black font-['Poppins'] text-blue-700 tracking-wider">
              PRODUCTS
            </h3>
            {onNavigate && (
              <button
                onClick={() => onNavigate('products')}
                className="text-xs font-semibold text-blue-600 hover:text-blue-800 flex items-center gap-1 cursor-pointer font-mono underline underline-offset-4"
              >
                <span>View Full Catalog</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </motion.div>

        {/* 3 Main Product Categories with Staggered Framer Motion Fade and Slide-In */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8 mb-16">
          {SKYMIRR_DATA.productCategories.map((cat, idx) => (
            <motion.div
              key={cat.id}
              initial={{ opacity: 0, y: 35 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.55, delay: idx * 0.12, ease: [0.22, 1, 0.36, 1] }}
              whileHover={{ y: -4, transition: { duration: 0.2 } }}
              className="bg-white border border-slate-200 hover:border-blue-500 rounded-3xl overflow-hidden transition-all duration-300 flex flex-col justify-between group shadow-xs hover:shadow-xl relative"
            >
              {/* Subtle top rim light */}
              <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-600 to-cyan-500 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

              <div>
                {/* 100% Complete Product Image Stage with Interactive Zoom/Magnify Trigger */}
                <div
                  onClick={() =>
                    openZoom(
                      cat.image,
                      cat.title,
                      cat.subtitle,
                      cat.items.map((it) => ({ label: 'Model', value: it })),
                      'Carrier Certified Hardware'
                    )
                  }
                  className="relative aspect-[16/10] w-full overflow-hidden bg-gradient-to-b from-slate-900 via-slate-950 to-slate-950 border-b border-slate-200/80 flex items-center justify-center p-4 sm:p-5 cursor-zoom-in group/stage"
                  title="Click to zoom and inspect in High-Resolution"
                >
                  {/* Subtle Blueprint Grid inside viewport */}
                  <div className="absolute inset-0 rf-grid opacity-20 pointer-events-none" />

                  {/* Soft Radial Ambient Behind Product */}
                  <div className="absolute w-36 h-36 rounded-full bg-cyan-500/10 blur-2xl pointer-events-none" />

                  <img
                    src={cat.image}
                    alt={cat.title}
                    className="max-h-full max-w-full object-contain relative z-10 group-hover/stage:scale-108 transition-transform duration-500 filter drop-shadow-[0_10px_20px_rgba(0,0,0,0.6)]"
                    loading="lazy"
                  />

                  {/* Top Category Badge */}
                  <div className="absolute top-3 left-3 z-20">
                    <span className="text-[10px] font-mono font-bold text-cyan-300 bg-slate-950/80 backdrop-blur-xs px-2.5 py-1 rounded-lg border border-cyan-500/30 uppercase tracking-wider block">
                      {cat.subtitle}
                    </span>
                  </div>

                  {/* Interactive Zoom Magnifier Pill on Hover */}
                  <div className="absolute top-3 right-3 z-20 opacity-0 group-hover/stage:opacity-100 transition-opacity duration-200">
                    <div className="px-2.5 py-1 rounded-lg bg-blue-600 text-white font-mono text-[10px] font-bold flex items-center gap-1 shadow-lg">
                      <ZoomIn className="w-3 h-3" />
                      <span>Zoom / Inspect</span>
                    </div>
                  </div>
                </div>

                {/* Clean Description & Specification Area */}
                <div className="p-6 space-y-4">
                  <div>
                    <h4 className="text-xl font-bold text-slate-950 font-['Poppins'] group-hover:text-blue-700 transition-colors">
                      {cat.title}
                    </h4>
                    <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed min-h-[3rem]">
                      {cat.description}
                    </p>
                  </div>

                  <div className="space-y-2 pt-3 border-t border-slate-100">
                    <div className="text-[11px] font-bold text-slate-900 uppercase tracking-wider font-mono flex items-center justify-between">
                      <span>Key Hardware Models</span>
                      <span className="text-[10px] text-blue-600 font-semibold font-mono">Carrier Grade</span>
                    </div>
                    {cat.items.map((item, i) => (
                      <div key={i} className="flex items-start gap-2 text-xs text-slate-700">
                        <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 shrink-0 mt-0.5" />
                        <span className="leading-snug">{item}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Card Footer Button */}
              <div className="p-6 pt-0 space-y-2">
                <button
                  onClick={() => {
                    if (onNavigate) {
                      onNavigate('products');
                    } else {
                      onOpenQuote(cat.title);
                    }
                  }}
                  className="w-full py-3 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition-all flex items-center justify-center gap-1.5 shadow-sm shadow-blue-500/20 cursor-pointer font-['Poppins'] active:scale-98"
                >
                  <span>Explore {cat.title} Specifications</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Panoramic Composite Banner from skymirr.com: Framer Motion Fade-In & Zoomable */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
          className="rounded-3xl bg-white border border-slate-200 p-6 sm:p-8 lg:p-10 flex flex-col lg:flex-row items-center justify-between gap-8 shadow-sm"
        >
          <div className="space-y-3.5 max-w-xl text-left w-full">
            <span className="text-xs font-mono font-bold text-blue-700 uppercase tracking-wider block">
              Antenna-First Engineering Suite
            </span>
            <h3 className="text-2xl sm:text-3xl font-bold text-slate-950 font-['Poppins'] leading-tight [text-wrap:balance]">
              Complete Sub-6 &amp; Wi-Fi 7 Connectivity Ecosystem
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              Whether deploying fixed wireless access across rural communities, equipping emergency first responder
              fleets, or designing custom micro-antennas for medical IoT, SkyMirr provides end-to-end RF excellence.
            </p>
            <div className="pt-2 flex flex-wrap items-center gap-3 sm:gap-4 text-xs font-semibold text-slate-700 font-mono">
              <span className="text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200/60">T-Mobile &amp; AT&amp;T Certified</span>
              <span className="text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200/60">CES 2026 Honoree</span>
              <span className="text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200/60">T-Priority Ready</span>
            </div>
          </div>

          <div
            onClick={() =>
              openZoom(
                '/images/our-products.png',
                'SkyMirr Complete RF Hardware Portfolio',
                'Carrier Certified Ecosystem',
                [
                  { label: 'Coverage', value: '617-5925 MHz' },
                  { label: 'Technology', value: 'MuLCAT® Multi-Layer' },
                  { label: 'Standard', value: '5G Sub-6 & Wi-Fi 7' },
                ],
                'CES® 2026 Innovation Honoree'
              )
            }
            className="w-full lg:max-w-md rounded-2xl overflow-hidden border border-slate-200 shadow-sm bg-gradient-to-b from-slate-50 to-white p-3 sm:p-4 flex items-center justify-center cursor-zoom-in group relative"
            title="Click to zoom high-resolution ecosystem hardware"
          >
            <img
              src="/images/our-products.png"
              alt="SkyMirr Hardware Family"
              className="max-h-64 sm:max-h-72 w-auto max-w-full object-contain rounded-xl group-hover:scale-104 transition-transform duration-300"
              loading="lazy"
            />
            <div className="absolute bottom-4 right-4 px-2.5 py-1 rounded-lg bg-slate-900/80 text-cyan-300 font-mono text-[10px] font-bold flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
              <ZoomIn className="w-3 h-3" />
              <span>Zoom In</span>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Global Image Zoom Lightbox Modal */}
      <ImageZoomModal
        isOpen={zoomModalData.isOpen}
        onClose={() => setZoomModalData((prev) => ({ ...prev, isOpen: false }))}
        imageSrc={zoomModalData.imageSrc}
        title={zoomModalData.title}
        subtitle={zoomModalData.subtitle}
        specs={zoomModalData.specs}
        highlight={zoomModalData.highlight}
      />
    </section>
  );
}
