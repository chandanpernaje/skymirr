import { useState, useEffect } from 'react';
import { Menu, X, ChevronDown, Phone, ArrowUpRight, Sparkles, Search } from 'lucide-react';

interface NavbarProps {
  activePage: string;
  onNavigate: (page: string) => void;
  onOpenQuote: () => void;
  onOpenSearch: () => void;
}

export function Navbar({ activePage, onNavigate, onOpenQuote, onOpenSearch }: NavbarProps) {
  const [scrolled, setScrolled] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [productsDropdownOpen, setProductsDropdownOpen] = useState(false);
  const [mobileProductsOpen, setMobileProductsOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const currentScroll = window.scrollY;
      setScrolled(currentScroll > 20);

      const totalHeight = document.documentElement.scrollHeight - window.innerHeight;
      if (totalHeight > 0) {
        setScrollProgress((currentScroll / totalHeight) * 100);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavClick = (page: string) => {
    onNavigate(page);
    setMobileMenuOpen(false);
    setProductsDropdownOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      {/* Top scroll progress indicator bar */}
      <div className="fixed top-0 left-0 right-0 z-50 h-[3px] bg-slate-100">
        <div
          className="h-full bg-gradient-to-r from-blue-700 via-sky-600 to-cyan-500 transition-all duration-75"
          style={{ width: `${scrollProgress}%` }}
        />
      </div>

      <header
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
          scrolled
            ? 'bg-white/95 backdrop-blur-md border-b border-slate-200/90 shadow-sm shadow-slate-200/40 py-2.5'
            : 'bg-white/90 backdrop-blur-sm border-b border-slate-100 py-3.5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center justify-between gap-2 sm:gap-4">
          {/* Logo matching https://skymirr.com/ */}
          <button
            onClick={() => handleNavClick('home')}
            className="flex items-center gap-2 group shrink-0 cursor-pointer text-left"
          >
            <img
              src="/images/skymirr-logo-3d.png"
              alt="SkyMirr"
              className="h-8 sm:h-10 w-auto object-contain transition-transform group-hover:scale-102"
            />
          </button>

          {/* Desktop Navigation Links from https://skymirr.com/ */}
          <nav className="hidden lg:flex items-center gap-4 xl:gap-5 text-xs font-semibold text-slate-700 font-['Poppins']">
            <button
              onClick={() => handleNavClick('home')}
              className={`transition-colors cursor-pointer ${
                activePage === 'home' ? 'text-blue-700 font-bold border-b-2 border-blue-600 pb-0.5' : 'hover:text-blue-600'
              }`}
            >
              Home
            </button>

            {/* Products Dropdown */}
            <div
              className="relative"
              onMouseEnter={() => setProductsDropdownOpen(true)}
              onMouseLeave={() => setProductsDropdownOpen(false)}
            >
              <button
                onClick={() => handleNavClick('products')}
                className={`flex items-center gap-1 py-1.5 transition-colors cursor-pointer ${
                  activePage === 'products' ? 'text-blue-700 font-bold border-b-2 border-blue-600 pb-0.5' : 'hover:text-blue-600'
                }`}
              >
                <span>Products</span>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400 group-hover:text-blue-600 transition-transform" />
              </button>

              {productsDropdownOpen && (
                <div className="absolute top-full left-0 w-52 bg-white rounded-xl shadow-xl border border-slate-200 py-2 z-50 animate-in fade-in slide-in-from-top-1 duration-150">
                  <button
                    onClick={() => handleNavClick('products')}
                    className="w-full text-left block px-4 py-2 text-xs font-semibold text-slate-700 hover:text-blue-600 hover:bg-slate-50 transition-colors"
                  >
                    All Products
                  </button>
                  <button
                    onClick={() => handleNavClick('products')}
                    className="w-full text-left block px-4 py-2 text-xs font-semibold text-slate-700 hover:text-blue-600 hover:bg-slate-50 transition-colors"
                  >
                    Antennas
                  </button>
                  <button
                    onClick={() => handleNavClick('products')}
                    className="w-full text-left block px-4 py-2 text-xs font-semibold text-slate-700 hover:text-blue-600 hover:bg-slate-50 transition-colors"
                  >
                    Routers (Sky5G™)
                  </button>
                  <button
                    onClick={() => handleNavClick('products')}
                    className="w-full text-left block px-4 py-2 text-xs font-semibold text-slate-700 hover:text-blue-600 hover:bg-slate-50 transition-colors"
                  >
                    Asset Trackers
                  </button>
                </div>
              )}
            </div>

            <button
              onClick={() => handleNavClick('technology')}
              className={`transition-colors cursor-pointer ${
                activePage === 'technology' ? 'text-blue-700 font-bold border-b-2 border-blue-600 pb-0.5' : 'hover:text-blue-600'
              }`}
            >
              Technology
            </button>

            <button
              onClick={() => handleNavClick('applications')}
              className={`transition-colors cursor-pointer ${
                activePage === 'applications' ? 'text-blue-700 font-bold border-b-2 border-blue-600 pb-0.5' : 'hover:text-blue-600'
              }`}
            >
              Applications
            </button>

            <button
              onClick={() => handleNavClick('partners')}
              className={`transition-colors cursor-pointer ${
                activePage === 'partners' ? 'text-blue-700 font-bold border-b-2 border-blue-600 pb-0.5' : 'hover:text-blue-600'
              }`}
            >
              Our Partners
            </button>

            <button
              onClick={() => handleNavClick('latest')}
              className={`transition-colors cursor-pointer ${
                activePage === 'latest' ? 'text-blue-700 font-bold border-b-2 border-blue-600 pb-0.5' : 'hover:text-blue-600'
              }`}
            >
              The Latest@skymirr
            </button>

            <button
              onClick={() => handleNavClick('about')}
              className={`transition-colors cursor-pointer ${
                activePage === 'about' ? 'text-blue-700 font-bold border-b-2 border-blue-600 pb-0.5' : 'hover:text-blue-600'
              }`}
            >
              About Us
            </button>

            <button
              onClick={() => handleNavClick('contact')}
              className={`transition-colors cursor-pointer ${
                activePage === 'contact' ? 'text-blue-700 font-bold border-b-2 border-blue-600 pb-0.5' : 'hover:text-blue-600'
              }`}
            >
              Contact Us
            </button>
          </nav>

          {/* Right Header Actions & Global Search Bar Trigger */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Desktop Instant Search Trigger */}
            <button
              onClick={onOpenSearch}
              className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200/90 border border-slate-200 text-slate-600 hover:text-slate-900 text-xs font-mono transition-all cursor-pointer shadow-2xs group"
              title="Search SkyMirr platform (⌘K / Ctrl+K)"
              aria-label="Search SkyMirr platform"
            >
              <Search className="w-3.5 h-3.5 text-blue-600 group-hover:scale-110 transition-transform" />
              <span className="hidden sm:inline font-medium text-slate-500 group-hover:text-slate-700 font-['Poppins']">
                Search...
              </span>
              <kbd className="hidden sm:inline px-1.5 py-0.5 text-[10px] font-bold bg-white text-slate-500 rounded border border-slate-300 shadow-2xs">
                ⌘K
              </kbd>
            </button>

            {/* Phone as shown on skymirr.com */}
            <a
              href="tel:321-393-1039"
              className="hidden xl:flex items-center gap-1.5 text-xs font-mono font-bold text-slate-700 hover:text-blue-600 bg-slate-50 hover:bg-blue-50 px-3 py-1.5 rounded-lg border border-slate-200 transition-colors"
            >
              <Phone className="w-3.5 h-3.5 text-blue-600" />
              <span>321-393-1039</span>
            </a>

            <button
              onClick={onOpenQuote}
              className="hidden md:inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors whitespace-nowrap shadow-xs active:scale-98 cursor-pointer font-['Poppins']"
            >
              <span>Connect with an Expert</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>

            {/* Mobile Hamburger Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-slate-700 hover:bg-slate-100 lg:hidden transition-colors border border-slate-200"
              aria-label="Toggle Mobile Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div className="lg:hidden border-t border-slate-200 bg-white shadow-2xl px-6 py-6 animate-in slide-in-from-top-4 duration-200 max-h-[85vh] overflow-y-auto">
            {/* Mobile Search Input Trigger */}
            <div className="mb-4">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenSearch();
                }}
                className="w-full flex items-center justify-between px-4 py-3 rounded-2xl bg-slate-50 hover:bg-blue-50/50 border border-slate-200 text-slate-500 text-xs font-['Poppins'] cursor-pointer transition-colors"
              >
                <div className="flex items-center gap-2.5">
                  <Search className="w-4 h-4 text-blue-600" />
                  <span>Search products, specs, firmware...</span>
                </div>
                <span className="text-[10px] font-mono font-bold bg-white px-2 py-0.5 rounded border border-slate-200 text-slate-600">
                  Search
                </span>
              </button>
            </div>

            <nav className="flex flex-col text-sm font-semibold text-slate-800 divide-y divide-slate-100 font-['Poppins']">
              <button
                onClick={() => handleNavClick('home')}
                className={`text-left py-3 transition-colors ${
                  activePage === 'home' ? 'text-blue-700 font-bold' : 'hover:text-blue-600'
                }`}
              >
                Home
              </button>

              {/* Mobile Products Accordion */}
              <div className="py-2">
                <button
                  onClick={() => setMobileProductsOpen(!mobileProductsOpen)}
                  className="w-full flex items-center justify-between py-2 hover:text-blue-600 transition-colors cursor-pointer"
                >
                  <span className={activePage === 'products' ? 'text-blue-700 font-bold' : ''}>
                    Products
                  </span>
                  <ChevronDown
                    className={`w-4 h-4 text-slate-400 transition-transform ${
                      mobileProductsOpen ? 'rotate-180' : ''
                    }`}
                  />
                </button>

                {mobileProductsOpen && (
                  <div className="pl-4 py-2 space-y-2 text-xs font-medium text-slate-600 bg-slate-50 rounded-lg my-1">
                    <button
                      onClick={() => handleNavClick('products')}
                      className="block w-full text-left py-1 hover:text-blue-600 cursor-pointer"
                    >
                      All Products Overview
                    </button>
                    <button
                      onClick={() => handleNavClick('products')}
                      className="block w-full text-left py-1 hover:text-blue-600 cursor-pointer"
                    >
                      Antennas (Ultra-Wideband)
                    </button>
                    <button
                      onClick={() => handleNavClick('products')}
                      className="block w-full text-left py-1 hover:text-blue-600 cursor-pointer"
                    >
                      Routers (Sky5G™ CPE)
                    </button>
                    <button
                      onClick={() => handleNavClick('products')}
                      className="block w-full text-left py-1 hover:text-blue-600 cursor-pointer"
                    >
                      Asset Trackers (SkyTrack™)
                    </button>
                  </div>
                )}
              </div>

              <button
                onClick={() => handleNavClick('technology')}
                className={`text-left py-3 transition-colors ${
                  activePage === 'technology' ? 'text-blue-700 font-bold' : 'hover:text-blue-600'
                }`}
              >
                Technology (MuLCAT®)
              </button>

              <button
                onClick={() => handleNavClick('applications')}
                className={`text-left py-3 transition-colors ${
                  activePage === 'applications' ? 'text-blue-700 font-bold' : 'hover:text-blue-600'
                }`}
              >
                Applications
              </button>

              <button
                onClick={() => handleNavClick('partners')}
                className={`text-left py-3 transition-colors ${
                  activePage === 'partners' ? 'text-blue-700 font-bold' : 'hover:text-blue-600'
                }`}
              >
                Our Partners &amp; Distributors
              </button>

              <button
                onClick={() => handleNavClick('latest')}
                className={`text-left py-3 transition-colors ${
                  activePage === 'latest' ? 'text-blue-700 font-bold' : 'hover:text-blue-600'
                }`}
              >
                The Latest @ SkyMirr
              </button>

              <button
                onClick={() => handleNavClick('about')}
                className={`text-left py-3 transition-colors ${
                  activePage === 'about' ? 'text-blue-700 font-bold' : 'hover:text-blue-600'
                }`}
              >
                About Us &amp; Leadership
              </button>

              <button
                onClick={() => handleNavClick('contact')}
                className={`text-left py-3 transition-colors ${
                  activePage === 'contact' ? 'text-blue-700 font-bold' : 'hover:text-blue-600'
                }`}
              >
                Contact Us
              </button>
            </nav>

            <div className="mt-6 pt-6 border-t border-slate-100 flex flex-col gap-3">
              <a
                href="tel:321-393-1039"
                className="w-full py-3 px-4 bg-slate-100 text-slate-800 text-xs font-mono font-bold rounded-xl flex items-center justify-center gap-2"
              >
                <Phone className="w-4 h-4 text-blue-600" />
                <span>Call Us: 321-393-1039</span>
              </a>

              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenQuote();
                }}
                className="w-full py-3 px-4 bg-blue-600 text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-2 font-['Poppins'] shadow-sm"
              >
                <span>Connect with an Expert</span>
                <ArrowUpRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </header>
    </>
  );
}
