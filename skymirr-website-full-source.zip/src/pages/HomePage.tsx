import { Hero } from '../components/Hero';
import { ProductCategoriesSection } from '../components/ProductCategoriesSection';
import { ScrollingImagesGallery } from '../components/ScrollingImagesGallery';
import { SolutionsSection } from '../components/SolutionsSection';
import { ScrollingPartnerMarquee } from '../components/ScrollingPartnerMarquee';
import { PartnersSection } from '../components/PartnersSection';
import { MulcatDeepDive } from '../components/MulcatDeepDive';
import { CustomerSuccessSection } from '../components/CustomerSuccessSection';
import { FirmwareSection } from '../components/FirmwareSection';
import { ContactSection } from '../components/ContactSection';

interface HomePageProps {
  onOpenQuote: (productName?: string) => void;
  onNavigate: (page: string) => void;
}

export function HomePage({ onOpenQuote, onNavigate }: HomePageProps) {
  return (
    <div className="w-full bg-white">
      {/* 1. HERO SLIDER (Preserved 100% full-image visibility) + Live Ticker + SIGNAL WITHOUT LIMITS + Animated Mouse */}
      <Hero onOpenQuote={() => onOpenQuote()} onNavigate={onNavigate} />

      {/* 2. WHEN IT HAS TO CONNECT, IT HAS TO BE SKYMIRR / CORE PRODUCTS (Clean, unobstructed card stages) */}
      <ProductCategoriesSection onOpenQuote={onOpenQuote} onNavigate={onNavigate} />

      {/* 3. PREMIUM INTERACTIVE HARDWARE SHOWCASE & CLICK-MOVE SLIDER (Deep-tech aerospace dark theme + Spec Inspector) */}
      <ScrollingImagesGallery onOpenQuote={onOpenQuote} onNavigate={onNavigate} />

      {/* 4. APPLICATIONS: Real-world deployments & biomedical engineering */}
      <SolutionsSection onNavigate={onNavigate} onOpenQuote={onOpenQuote} />

      {/* 5. OUR PARTNERS: Online Partners & Partners & Distributors with marquee */}
      <div className="border-t border-slate-200">
        <ScrollingPartnerMarquee />
        <PartnersSection onNavigate={onNavigate} />
      </div>

      {/* 6. DISCOVER SKYMIRR / TAKE A CLOSER LOOK.... (3D Anechoic Lab Demonstration Video + Responsive MuLCAT® Simulator + 5 Advantages) */}
      <MulcatDeepDive onNavigate={onNavigate} />

      {/* 7. CUSTOMER SUCCESS SCENARIO: Retail Expansion Without Connectivity Delays */}
      <CustomerSuccessSection onOpenQuote={onOpenQuote} />

      {/* 8. DOWNLOAD LATEST FIRMWARE: Sky5G™ Router (TCPA-117) Form */}
      <FirmwareSection />

      {/* 9. CONNECT WITH AN EXPERT & 321-393-1039 DIRECT HOTLINE FORM */}
      <ContactSection />
    </div>
  );
}
