import { SKYMIRR_DATA } from '../data/skymirrData';
import { WaveCanvas } from '../components/WaveCanvas';
import { CheckCircle2, ArrowRight, Activity, Shield, Layers, Radio, Cpu, Download } from 'lucide-react';

interface TechnologyPageProps {
  onOpenQuote: (productName?: string) => void;
  onNavigate: (page: string) => void;
}

export function TechnologyPage({ onOpenQuote, onNavigate }: TechnologyPageProps) {
  const tech = SKYMIRR_DATA.mulcatTechnology;

  return (
    <div className="pt-24 pb-20 bg-white">
      {/* Page Header */}
      <section className="relative py-16 bg-gradient-to-b from-[#001738] via-[#05224D] to-[#001738] text-white overflow-hidden">
        <WaveCanvas opacity={0.18} speed={0.9} />
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <div className="max-w-3xl">
            <div className="text-xs font-mono font-bold tracking-widest text-cyan-300 uppercase mb-2">
              Patented Electromagnetic Innovation
            </div>
            <h1 className="text-3xl sm:text-5xl font-extrabold font-['Poppins'] tracking-tight text-white leading-tight">
              Proprietary MuLCAT® Technology
            </h1>
            <p className="text-slate-300 text-sm sm:text-base mt-3 leading-relaxed">
              Multi-Layer Coupling Controlled Antenna Technology. Transforming electromagnetic coupling from destructive interference into constructive radiated power.
            </p>
          </div>
        </div>
      </section>

      {/* Main Philosophy Section: Inverting the Paradigm */}
      <section className="py-20 max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-7 space-y-6">
            <div className="text-xs font-bold text-blue-700 tracking-wider uppercase font-mono">
              The Physics Behind MuLCAT®
            </div>
            <h2 className="text-2xl sm:text-4xl font-extrabold text-slate-950 font-['Poppins'] leading-tight">
              Inverting 50 Years of Radio Frequency Engineering
            </h2>
            <p className="text-sm sm:text-base text-slate-700 leading-relaxed">
              {tech.lead}
            </p>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed bg-slate-50 border border-slate-200 p-5 rounded-2xl">
              {tech.mechanism}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4">
              <div className="p-4 rounded-xl bg-blue-50/70 border border-blue-200/80 text-center">
                <div className="text-2xl font-bold font-mono text-blue-700">+42%</div>
                <div className="text-xs text-slate-700 font-semibold mt-1">Farther Tower Reach</div>
              </div>
              <div className="p-4 rounded-xl bg-blue-50/70 border border-blue-200/80 text-center">
                <div className="text-2xl font-bold font-mono text-blue-700">2x</div>
                <div className="text-xs text-slate-700 font-semibold mt-1">Cell-Edge Throughput</div>
              </div>
              <div className="p-4 rounded-xl bg-blue-50/70 border border-blue-200/80 text-center">
                <div className="text-2xl font-bold font-mono text-blue-700">10x</div>
                <div className="text-xs text-slate-700 font-semibold mt-1">Usable Bandwidth</div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-5 bg-gradient-to-br from-slate-900 to-[#0A192F] p-8 rounded-3xl border border-blue-500/30 text-white shadow-xl">
            <h3 className="text-lg font-bold font-['Poppins'] text-cyan-300 mb-4 flex items-center gap-2">
              <Layers className="w-5 h-5 text-cyan-400" />
              <span>Multi-Layer Dielectric Coupling</span>
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed mb-6">
              Conventional antennas isolate radiating dipoles with ground planes and ferrite beads. MuLCAT® introduces precise geometric dielectric layers that harness electromagnetic proximity to expand resonance from 617 MHz to 6000 MHz.
            </p>

            <div className="space-y-3 border-t border-white/10 pt-4">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-slate-400">Radiation Efficiency:</span>
                <span className="text-cyan-300 font-bold">&gt; 85% Across All Bands</span>
              </div>
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-slate-400">VSWR Metric:</span>
                <span className="text-emerald-400 font-bold">&lt; 1.8:1 Continuous</span>
              </div>
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-slate-400">Switching Relays:</span>
                <span className="text-cyan-300 font-bold">Zero (Passive Resonance)</span>
              </div>
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-slate-400">RF Loss Elimination:</span>
                <span className="text-cyan-300 font-bold">-3.2 dB Insertion Loss Saved</span>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-white/10">
              <button
                onClick={() => onOpenQuote('MuLCAT® Technology Evaluation')}
                className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs rounded-xl transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-md"
              >
                <span>Request Technical Evaluation Whitepaper</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 5 Core Pillars */}
      <section className="py-20 bg-[#F8FAFC] border-y border-slate-200">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <div className="text-xs font-bold text-blue-700 tracking-wider uppercase font-mono mb-2">
              Performance Advantages
            </div>
            <h2 className="text-3xl font-extrabold font-['Poppins'] text-slate-950">
              Why MuLCAT® Outperforms Conventional Dipoles
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 mt-2">
              Tested and verified in 3D microwave anechoic chambers at our R&amp;D facility in Songdo Bio-IT Complex, Incheon.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {tech.advantages.map((adv, idx) => (
              <div
                key={idx}
                className="bg-white border border-slate-200 hover:border-blue-400 rounded-2xl p-6 transition-all hover:shadow-lg shadow-xs flex flex-col justify-between"
              >
                <div>
                  <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center font-bold text-sm mb-4 font-mono">
                    0{idx + 1}
                  </div>
                  <h3 className="text-base font-bold font-['Poppins'] text-slate-900">
                    {adv.title}
                  </h3>
                  <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                    {adv.desc}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-slate-100 flex items-center gap-1.5 text-xs text-blue-600 font-semibold">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Verified in 3D Anechoic Testing</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Frequency Band Support Table */}
      <section className="py-20 max-w-7xl mx-auto px-6">
        <div className="max-w-3xl mb-10">
          <div className="text-xs font-bold text-blue-700 tracking-wider uppercase font-mono mb-2">
            RF Spectrum Matrix
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold font-['Poppins'] text-slate-950">
            Broadband Carrier &amp; Unlicensed Band Allocation
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 mt-2">
            MuLCAT® delivers single-structure ultra-wideband coverage without mechanical switching or lossy diplexers.
          </p>
        </div>

        <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-white shadow-xs">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-700 font-mono text-[11px] uppercase tracking-wider">
                <th className="p-4">Spectrum Band</th>
                <th className="p-4">Frequency Range</th>
                <th className="p-4">Primary Application</th>
                <th className="p-4">Typical VSWR</th>
                <th className="p-4">Peak Gain</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {SKYMIRR_DATA.frequencyBands.map((band) => (
                <tr key={band.id} className="hover:bg-blue-50/40 transition-colors">
                  <td className="p-4 font-bold text-slate-900 font-['Poppins']">
                    {band.name}
                  </td>
                  <td className="p-4 font-mono text-blue-700 font-semibold">
                    {band.range}
                  </td>
                  <td className="p-4 text-slate-600">
                    <span className="font-semibold text-slate-900 block">{band.designation}</span>
                    <span className="text-[11px] text-slate-500">{band.useCase}</span>
                  </td>
                  <td className="p-4 font-mono text-emerald-600 font-semibold">
                    {band.vswr}
                  </td>
                  <td className="p-4 font-mono text-slate-900 font-bold">
                    {band.gainDbi} dBi
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* Medical Microwave Applications */}
      <section className="py-16 bg-[#001738] text-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-8 space-y-4">
              <span className="text-xs font-mono font-bold tracking-widest text-cyan-300 uppercase">
                Healthcare &amp; Life Sciences
              </span>
              <h2 className="text-2xl sm:text-4xl font-extrabold font-['Poppins']">
                MuLCAT® in Medical Cancer &amp; Disease Therapies
              </h2>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                Beyond telecommunications, SkyMirr’s electromagnetic coupling physics are deployed in specialized microwave biomedical instrumentation. By concentrating constructive RF fields into localized tissue, MuLCAT® enables precision non-invasive cancer detection and focused thermal ablation therapies.
              </p>
            </div>
            <div className="lg:col-span-4 flex justify-start lg:justify-end">
              <button
                onClick={() => onNavigate('applications')}
                className="px-6 py-3.5 bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs rounded-xl transition-colors shadow-lg shadow-blue-600/30 flex items-center gap-2 cursor-pointer"
              >
                <span>View Medical Applications</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
