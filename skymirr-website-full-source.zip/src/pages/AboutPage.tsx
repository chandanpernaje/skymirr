import { TeamSection } from '../components/TeamSection';
import { WaveCanvas } from '../components/WaveCanvas';
import { SKYMIRR_DATA } from '../data/skymirrData';
import { Building, MapPin, Award, Shield, CheckCircle2, Phone, Mail } from 'lucide-react';

interface AboutPageProps {
  onOpenQuote: (productName?: string) => void;
  onNavigate: (page: string) => void;
}

export function AboutPage({ onOpenQuote, onNavigate }: AboutPageProps) {
  const company = SKYMIRR_DATA.company;

  return (
    <div className="pt-24 pb-20 bg-white">
      {/* Header */}
      <section className="relative py-16 bg-gradient-to-b from-[#001738] via-[#05224D] to-[#001738] text-white overflow-hidden">
        <WaveCanvas opacity={0.16} speed={0.8} />
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <div className="max-w-3xl">
            <div className="text-xs font-mono font-bold tracking-widest text-cyan-300 uppercase mb-2">
              Corporate Overview &amp; Leadership
            </div>
            <h1 className="text-3xl sm:text-5xl font-extrabold font-['Poppins'] tracking-tight text-white leading-tight">
              About SkyMirr Technologies
            </h1>
            <p className="text-slate-300 text-sm sm:text-base mt-3 leading-relaxed">
              Pioneering antenna-first wireless technology to better connect humanity, empower enterprise continuity, and advance medical healing.
            </p>
          </div>
        </div>
      </section>

      {/* Mission & Facilities Section */}
      <section className="py-20 max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-6 space-y-6">
            <div className="text-xs font-bold text-blue-700 tracking-wider uppercase font-mono">
              Our Founding Story
            </div>
            <h2 className="text-2xl sm:text-4xl font-extrabold font-['Poppins'] text-slate-950 leading-tight">
              Reinventing Wireless From The Field Outward
            </h2>
            <p className="text-sm sm:text-base text-slate-700 leading-relaxed">
              Founded by telecommunications and antenna veterans with executive roots at Samsung Electronics, Taoglas, SkyCross, and L3Harris, SkyMirr was established on a radical breakthrough: turning destructive antenna coupling into an electromagnetic multiplier.
            </p>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              Today, SkyMirr operates global executive headquarters in Melbourne, Florida and an advanced microwave research center with full 3D anechoic chambers in the Songdo Bio-IT Complex, Incheon, South Korea.
            </p>

            <div className="pt-4 grid grid-cols-2 gap-4">
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-900 font-['Poppins'] mb-1">
                  <MapPin className="w-4 h-4 text-blue-600" />
                  <span>Melbourne, Florida</span>
                </div>
                <div className="text-[11px] text-slate-500">Global Corporate Headquarters &amp; Operations</div>
              </div>

              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-900 font-['Poppins'] mb-1">
                  <Building className="w-4 h-4 text-blue-600" />
                  <span>Songdo Incheon, Korea</span>
                </div>
                <div className="text-[11px] text-slate-500">3D Anechoic Microwave R&amp;D Complex</div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-6">
            <div className="rounded-3xl overflow-hidden border border-slate-200 shadow-xl bg-slate-900">
              <img
                src="/images/disocver-skymirr.jpg"
                alt="SkyMirr 3D Anechoic Laboratory"
                className="w-full h-auto object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Complete Official Team Section with 14 Portraits & Bio Modals */}
      <TeamSection />
    </div>
  );
}
