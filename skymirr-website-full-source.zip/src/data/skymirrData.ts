export interface Product {
  id: string;
  name: string;
  category: 'router' | 'antenna' | 'tracker' | 'embedded';
  image: string;
  tagline: string;
  description: string;
  award?: string;
  specs: {
    frequency?: string;
    gain?: string;
    technology?: string;
    capacity?: string;
    reachBonus?: string;
    throughputBonus?: string;
    formFactor?: string;
    connectors?: string;
    dimensions?: string;
    power?: string;
    certification?: string;
  };
  features: string[];
  bands: string[];
  datasheetUrl?: string;
  hotspots?: { title: string; desc: string; x: number; y: number }[];
}

export interface FrequencyBand {
  id: string;
  name: string;
  range: string;
  designation: string;
  useCase: string;
  vswr: string;
  gainDbi: number;
}

export interface Solution {
  id: string;
  title: string;
  tagline: string;
  description: string;
  metrics: string[];
  icon: string;
}

export interface TeamMember {
  name: string;
  role: string;
  category: 'leadership' | 'board' | 'advisory';
  credentials?: string;
  image?: string;
  bio?: string;
}

export interface Partner {
  name: string;
  category: 'Online Partner' | 'Distributor';
  image: string;
  url: string;
}

export interface NewsItem {
  id: string;
  date: string;
  title: string;
  publication: string;
  summary: string;
  badge: string;
  link?: string;
}

export const SKYMIRR_DATA = {
  company: {
    name: 'SkyMirr',
    legalName: 'SkyMirr Technologies, Inc.',
    tagline: 'Antenna-First 5G & RF Connectivity',
    slogan: 'SIGNAL WITHOUT LIMITS',
    secondarySlogan: 'WHEN IT HAS TO CONNECT, IT HAS TO BE SKYMIRR',
    mission: 'Revolutionizing wireless connectivity by engineering high-performance systems from the electromagnetic field outwards with patented MuLCAT® technology.',
    founded: '2021',
    headquarters: '930 S. Harbor City Blvd, Suite 403, Melbourne, FL 32901',
    rdLab: 'Songdo Bio-IT Complex, Incheon, South Korea',
    phone: '321-393-1039',
    salesEmail: 'sales@skymirr.com',
    supportEmail: 'support@skymirr.com',
    logoUrl: '/images/skymirr-logo-3d.png',
    footerLogoUrl: '/images/skymirr-logo-footer.png',
  },

  stats: [
    { value: '+42%', label: 'Extended Tower Reach', detail: 'Compared to conventional 5G CPE systems' },
    { value: '2.0x', label: 'Cell-Edge Throughput', detail: 'In fringe signal & high-interference zones' },
    { value: '10x', label: 'Bandwidth Expansion', detail: 'Multi-octave coverage via MuLCAT® positive coupling' },
    { value: '512', label: 'Concurrent Clients', detail: 'Managed effortlessly with Wi-Fi 7 tri-band' },
  ],

  certifications: [
    { name: 'CES® 2026 Honoree', category: 'Mobile Devices & Apps', detail: 'Recognized for Sky5G™ Router engineering excellence' },
    { name: 'T-Mobile 5G Certified', category: 'Carrier Integration', detail: 'Approved for nationwide ultra-capacity 5G network' },
    { name: 'T-Priority Approved', category: 'First Responders', detail: 'Mission-critical priority tier for emergency services' },
    { name: 'AT&T Certified', category: 'Network Certification', detail: 'Certified for expanding carrier choice & reliability' },
    { name: 'FCC & CE Compliant', category: 'Regulatory Standards', detail: 'RoHS 3, PTCRB, and global RF safety certifications' },
  ],

  productCategories: [
    {
      id: 'antennas',
      title: 'Antennas',
      subtitle: 'Powered by Patented MuLCAT® Technology',
      image: '/images/antennas-new.jpg',
      description: 'World-class 4G/5G Sub-6 and Wi-Fi 6E/7 omnidirectional antennas engineered for exceptional lower-band efficiency and zero dipole degradation.',
      items: ['SkyBlade™ TAMP141 (Ultra-Wideband 617-5925 MHz)', 'SkyBlade™ TAMP161 (MIMO Broadband Module)', 'SkyBlade™ TAMP159 / TAMP154 (Wi-Fi 7 Omnis)'],
    },
    {
      id: 'routers',
      title: '5G Routers',
      subtitle: 'Award-Winning Sky5G™ / TCPA-117 Gateway',
      image: '/images/5g-routers.jpg',
      description: 'Carrier-certified next-generation 5G CPE router featuring internal MuLCAT® antenna arrays, Wi-Fi 7 (802.11be), dual SIM failover, and +42% reach to cell towers.',
      items: ['CES® 2026 Innovation Honoree', 'T-Mobile & AT&T Certified', 'T-Priority FirstNet Ready'],
    },
    {
      id: 'trackers',
      title: 'Asset Trackers & IoT',
      subtitle: 'Ruggedized Remote Telemetry',
      image: '/images/asset-trackers.jpg',
      description: 'Ultra-low-power, long-range cellular tracking devices and embedded NFC micro-antennas built for harsh industrial environments, cold chain, and medical biosensors.',
      items: ['Industrial GPS / Cellular Trackers', 'BioTrack™ MAEP103 NFC Sensor Coils', 'Extended Multi-Year Battery Architecture'],
    },
  ],

  products: [
    {
      id: 'sky5g-router',
      name: 'Sky5G™ Wireless Router (TCPA-117)',
      category: 'router',
      image: '/images/5g-routers.jpg',
      tagline: 'Next-Generation High-Gain 5G & Wi-Fi 7 CPE Gateway',
      description: 'Engineered from the antenna outwards with proprietary MuLCAT® architecture. The Sky5G delivers up to 42% farther reach to cell towers, double the throughput at the cell edge, and penetrates reinforced concrete structures with unmatched stability.',
      award: 'CES® 2026 Innovation Awards Honoree',
      specs: {
        technology: '5G Sub-6 NSA/SA, 4G LTE-A Cat 20, Wi-Fi 7 (802.11be)',
        frequency: '617 MHz – 5925 MHz (Global 5G Sub-6)',
        reachBonus: 'Up to 42% farther cell tower acquisition',
        throughputBonus: 'Up to 2x higher throughput in low SNR / interference zones',
        capacity: 'Up to 512 concurrent active devices',
        connectors: '2.5G WAN/LAN Port, 4x Gigabit LAN, 4x External SMA RF Ports',
        dimensions: '210 mm x 135 mm x 68 mm',
        power: '12V DC / 3.0A with backup battery support',
        certification: 'T-Mobile 5G, T-Priority, AT&T Network Certified, FCC, CE, RoHS 3',
      },
      features: [
        'Proprietary MuLCAT® internal high-isolation antenna array',
        'Next-generation Wi-Fi 7 (802.11be) with 320 MHz channels and 4K-QAM',
        'T-Priority certified for emergency services and first responder priority tiers',
        'Dual SIM auto-failover with real-time carrier health probing',
        'Enterprise IPsec/WireGuard VPN and hardware-accelerated firewall',
        'External antenna bypass switches for remote or shielded deployments',
      ],
      bands: ['n71 (600MHz)', 'n41 (2.5GHz)', 'n77/n78 (3.5-3.8GHz C-Band)', 'n25/n66', 'B14 FirstNet'],
      datasheetUrl: 'Sky5G_TCPA117_Datasheet.pdf',
      hotspots: [
        { title: 'MuLCAT® Integrated Array', desc: 'Custom multi-layer coupling antenna core eliminating blind spots and cross-interference.', x: 48, y: 22 },
        { title: 'Wi-Fi 7 Tri-Band Engine', desc: '320 MHz channel width delivering ultra-low 2ms wireless latency for mission-critical tasks.', x: 74, y: 45 },
        { title: 'Quad Gigabit + 2.5G WAN', desc: 'Hardware line-rate packet processing with redundant WAN auto-fallback.', x: 26, y: 76 },
        { title: 'Active Thermal Exhaust', desc: 'Acoustically tuned silent heat pipe keeping RF amplifiers in peak efficiency envelope.', x: 80, y: 82 },
      ],
    },
    {
      id: 'skyblade-tamp141',
      name: 'SkyBlade™ TAMP141',
      category: 'antenna',
      image: '/images/antennas-new.jpg',
      tagline: "World's First True Global 5G Ultra-Wideband Omni Antenna",
      description: 'A revolutionary external connectorized omnidirectional whip antenna covering the entire spectrum from 617 MHz to 5925 MHz with high gain and exceptional low-band efficiency. Designed for routers, IoT gateways, and vehicle terminals.',
      specs: {
        frequency: '617–960 MHz / 1447–2690 MHz / 3300–5925 MHz',
        gain: 'Up to 6.0 dBi peak isotropic gain',
        formFactor: 'Ultra-durable whip with precision hinge articulation',
        connectors: 'Precision gold-plated SMA Male (50 Ohm impedance)',
        dimensions: '7.87" (200 mm) H x 1.42" (36 mm) W x 0.51" (13 mm) D',
        power: 'Passive high-efficiency design (no external power required)',
        certification: 'RoHS 3, REACH, IP65 weather-resistant housing',
      },
      features: [
        'Patent-pending MuLCAT® phase-coupling architecture',
        'Eliminates need for swapping antennas across regional bands',
        'Optimized for tricky lower 600 MHz (Band 71) rural frequencies',
        'Zero-dipole degradation in close proximity to metallic mounting plates',
        'Heavy-duty UV-stabilized polycarbonate radome in signature navy finish',
      ],
      bands: ['617 - 960 MHz', '1447 - 2690 MHz', '3300 - 5925 MHz'],
      datasheetUrl: 'SkyBlade_TAMP141_Datasheet.pdf',
      hotspots: [
        { title: 'Wideband Radiator', desc: 'Continuous multi-octave impedance matching with VSWR < 2.2:1.', x: 50, y: 25 },
        { title: 'Hinged Joint System', desc: '90-degree detent articulation for optimal polarization alignment.', x: 50, y: 68 },
        { title: 'Gold-Plated SMA', desc: 'Low-loss micro-precision coaxial termination.', x: 50, y: 90 },
      ],
    },
    {
      id: 'skyblade-tamp161',
      name: 'SkyBlade™ TAMP161 MIMO',
      category: 'antenna',
      image: '/images/our-products.png',
      tagline: '4G LTE / 5G High-Performance Broadband MIMO Module',
      description: 'Integrated dual-polarization omnidirectional antenna module engineered for high-density IoT telemetry, industrial automation gateways, and autonomous fleet vehicles requiring rugged multi-path reception.',
      specs: {
        frequency: '617 MHz – 5850 MHz Full Sub-6',
        gain: '5.5 dBi omnidirectional',
        formFactor: 'Low-profile ruggedized puck / module mount',
        connectors: 'Dual SMA / RP-SMA with low-loss RG58 cabling',
        dimensions: '140 mm diameter x 45 mm profile',
        certification: 'IP67 waterproof, MIL-STD-810H shock and vibration',
      },
      features: [
        'Dual cross-polarized elements for maximum spatial multiplexing',
        'Ultra-low ground plane dependency',
        'High inter-port isolation (>20 dB across all active bands)',
      ],
      bands: ['Sub-6 5G', '4G LTE-A', 'CBRS 3.5GHz'],
    },
    {
      id: 'skyblade-tamp159',
      name: 'SkyBlade™ TAMP159 Wi-Fi 7',
      category: 'antenna',
      image: '/images/antennas-new.jpg',
      tagline: 'High-Gain Dual/Tri-Band Wi-Fi 6E & 7 Omni Antenna',
      description: 'Precision-tuned omnidirectional antenna engineered specifically for 2.4 GHz, 5.8 GHz, and the 6 GHz Wi-Fi 6E/7 bands. Provides uniform 360-degree toroidal radiation with high front-to-back symmetry.',
      specs: {
        frequency: '2400–2500 MHz / 5150–5850 MHz / 5925–7125 MHz',
        gain: '4.8 dBi / 6.2 dBi peak gain',
        formFactor: 'Articulated high-gain dipole',
        connectors: 'RP-SMA Male',
        dimensions: '165 mm H x 20 mm W',
        certification: 'RoHS 3 compliant',
      },
      features: [
        'Covers ultra-wide 6 GHz channels (up to 320 MHz channel allocation)',
        'Low dielectric loss fluoropolymer internal insulators',
        'Interference mitigation from adjacent cellular bands',
      ],
      bands: ['2.4 GHz', '5 GHz', '6 GHz Wi-Fi 7'],
    },
    {
      id: 'asset-tracker-pro',
      name: 'SkyTrack™ Industrial Asset Tracker',
      category: 'tracker',
      image: '/images/asset-trackers.jpg',
      tagline: 'Ruggedized Global LTE-M / NB-IoT & GPS Tracker',
      description: 'Heavy-duty telemetry device with internal MuLCAT® patch antennas delivering maximum signal sensitivity in shipping containers, rail cars, and heavy machinery.',
      specs: {
        frequency: 'Global LTE Cat-M1 / NB-IoT / Quad-band 2G',
        gain: 'High-sensitivity internal active GPS + cellular',
        formFactor: 'IP68 submersible hermetic polycarbonate case',
        dimensions: '118 mm x 68 mm x 26 mm',
        power: 'Replaceable LiSOCl2 battery (up to 7 years battery life)',
        certification: 'ATEX Zone 2 hazardous location certified',
      },
      features: [
        'Internal MuLCAT® antenna maintains lock inside shipping containers',
        'Integrated tri-axial accelerometer, shock, and temperature sensors',
        'Bluetooth 5.2 Low Energy for local sensor tag aggregation',
      ],
      bands: ['B1/B2/B3/B4/B5/B8/B12/B13/B18/B19/B20/B26/B28'],
    },
  ] as Product[],

  partners: [
    { name: 'Amazon', category: 'Online Partner', image: '/images/partner-amazon.jpg', url: 'https://www.amazon.com' },
    { name: 'Walmart', category: 'Online Partner', image: '/images/partner-walmart.jpg', url: 'https://www.walmart.com' },
    { name: 'DigiKey', category: 'Online Partner', image: '/images/partner-digikey.jpg', url: 'https://www.digikey.com' },
    { name: 'Central Computers', category: 'Online Partner', image: '/images/partner-central-computers.png', url: 'https://www.centralcomputer.com' },
    { name: 'B&H Photo Video', category: 'Online Partner', image: '/images/partner-bandh.jpg', url: 'https://www.bhphotovideo.com' },
    { name: 'ThinkEdu', category: 'Online Partner', image: '/images/partner-think-edu.png', url: 'https://www.thinkedu.com' },
    { name: 'Semikart', category: 'Distributor', image: '/images/partner-semikart.jpg', url: 'https://www.semikart.com' },
    { name: 'D&H Distributing', category: 'Distributor', image: '/images/partner-dandh.jpg', url: 'https://www.dandh.com' },
    { name: 'CellHub', category: 'Distributor', image: '/images/partner-cellhub.jpg', url: 'https://www.cellhub.com' },
    { name: 'Advent', category: 'Distributor', image: '/images/partner-advent.jpg', url: 'https://skymirr.com' },
    { name: 'Aqtronics', category: 'Distributor', image: '/images/partner-aqtronics.jpg', url: 'https://skymirr.com' },
  ] as Partner[],

  team: [
    {
      name: 'Eric (Youngmin) Jo, Ph.D.',
      role: 'Co-Founder and Chief Executive Officer',
      category: 'leadership',
      image: '/images/team/eric-jo.jpg',
      bio: 'Over 25 years of experience in RF/antenna technology and operations management. Former global VP of Operations at Taoglas, Co-Founder/CEO of SkyCross with 600 employees, and executive at Samsung Electronics. Holds over 35 patents for antenna and RF systems. Ph.D. in Electrical Engineering from Florida Tech.',
    },
    {
      name: 'Christopher Morton, Ph.D.',
      role: 'Co-Founder and Board Chairman',
      category: 'leadership',
      image: '/images/team/chris-morton.jpg',
      bio: 'Over 30 years of executive leadership in IT, display, and wireless communications. CEO of NanoPhotonica, Operating Partner in Orchid Black, with over $85M raised from leading institutional VCs. Ph.D. in Communication Systems from University of Pennsylvania.',
    },
    {
      name: 'Kerry Greer, MSEE, MBA',
      role: 'CSO and Co-Founder',
      category: 'leadership',
      image: '/images/team/kerry-greer.jpg',
      bio: 'Over 30 years leading R&D, business development, volume manufacturing, and systems engineering at Globalstar, L3Harris Communications, and ACR Electronics. Holds 10+ patents in RF communications. MSEE and MBA from University of Florida.',
    },
    {
      name: 'Frank (Tae Ho) Son, Ph.D.',
      role: 'Chief Scientist',
      category: 'leadership',
      image: '/images/team/frank-son.jpg',
      bio: 'Over 30 years in RF/microwave, antenna, and medical diagnostics. Professor Emeritus at Soonchunhyang University, senior researcher at LGE Central Lab for radar/missile guidance, researcher at KASI. Published over 316 research papers and 34 patents. Ph.D. from Hanyang University.',
    },
    {
      name: 'Bob Miller',
      role: 'Chief Financial Officer',
      category: 'leadership',
      image: '/images/team/bob-miller.jpg',
      bio: 'Two decades of executive CFO/COO experience raising capital and commercializing technology. Former CFO of GAF Corporation, Treasurer of Mead Corporation ($4B revenue), US Marine Corps veteran. Degrees in economics and industrial engineering from Stanford and MBA from Columbia University.',
    },
    {
      name: 'Natasha Tamaskar, Ph.D.',
      role: 'Chief Revenue Officer',
      category: 'leadership',
      image: '/images/team/natasha-tamaskar.jpg',
      bio: 'Global technology executive with deep experience leading commercialization, product strategy, and market expansion across telecommunications and cloud infrastructure. Ph.D. in Physics and MBA, passionate about applied generative AI for digital transformation.',
    },
    {
      name: 'Carl Lee, MSEE',
      role: 'VP of Sales and PM, Korea',
      category: 'leadership',
      image: '/images/team/carl-lee.jpg',
      bio: 'Over 25 years of global sales and project management in the RF/antenna industry. Previously served top-tier companies including SkyCross, LG Electronics, and ePlus in regional VP and GM roles. Master of Science in Electrical Engineering from Florida Tech.',
    },
    {
      name: 'Mark Banish',
      role: 'Senior Director of Operations',
      category: 'leadership',
      image: '/images/team/mark-banish.jpg',
      bio: 'Senior director of global operational execution, manufacturing logistics, quality control systems, and supplier chain optimization across North America and Asia-Pacific telecommunications channels.',
    },
    {
      name: 'Greg Khachatrian',
      role: 'Board Director',
      category: 'board',
      image: '/images/team/greg-khachatrian.jpg',
      bio: 'Experienced venture board director, business strategist, and corporate governance leader specializing in scaling hardware technology companies and global institutional partnerships.',
    },
    {
      name: 'Don Hawley',
      role: 'Company Board Member',
      category: 'board',
      image: '/images/team/don-hawley.jpg',
      bio: 'Industry expert in corporate finance, business operations, and emerging industry trend analysis. Partner in 2Go Advisory Group, President of hhharvest.co, former chairman in Vistage Worldwide. BS from UC Berkeley.',
    },
    {
      name: 'Dr. Donna Hamlin, Ph.D.',
      role: 'Independent Board Member',
      category: 'board',
      image: '/images/team/donna-hamlin.jpg',
      bio: 'Board director and advisor in strategy, corporate governance, and business transformation. Developer of CASCADE® and Board Bona Fide® management tools. Founder of Boardwise, Inc. Ph.D. and M.S. from Rensselaer Polytechnic Institute.',
    },
    {
      name: 'David Carrier',
      role: 'Advisory Board Member',
      category: 'advisory',
      image: '/images/team/david-carrier.jpg',
      bio: 'Industrial sales and manufacturing expert. Founder and President of QuantumFlo, Inc., an international leader in advanced variable-speed pump systems. Advisory board chairman in GrowFL. BS from University of South Florida.',
    },
    {
      name: 'Yoshioki Chika',
      role: 'Advisory Board Member',
      category: 'advisory',
      image: '/images/team/yoshioki-chika.jpg',
      bio: 'Telecommunications mobile carrier expert, former CTO of mobile carriers in Japan and senior advisor to Sprint CTO. Board member of MulteFire Alliance, former VP of Softbank Solution Strategy, and 20 years at KDDI. Degree in Physics from Ibaraki University.',
    },
    {
      name: 'Alex Wissner-Gross, Ph.D.',
      role: 'Advisory Board Member',
      category: 'advisory',
      image: '/images/team/alex-wissner-gross.jpg',
      bio: 'Award-winning computer scientist, entrepreneur, and investor. President and Chief Scientist of Gemedy, taught at Harvard and MIT. Founded/invested in 27 companies with combined valuation >$850M. Ph.D. in Physics from Harvard and S.B. from MIT.',
    },
  ] as TeamMember[],

  mulcatTechnology: {
    title: 'Proprietary MuLCAT® Technology',
    subtitle: 'Multi-Layer Coupling Controlled Antenna Technology',
    lead: 'For decades, wireless engineers fought antenna coupling as a destructive parasite that causes return loss, detuning, and signal cancellation. SkyMirr inverted the paradigm.',
    mechanism: 'MuLCAT® uses positive electromagnetic coupling through proprietary multi-layer dielectric resonator geometries. Rather than isolating elements with bulky chokes or lossy shielding, MuLCAT® constructively aligns the phase of adjacent fields to amplify radiation efficiency and multiply usable bandwidth.',
    advantages: [
      {
        title: '10x Usable Bandwidth',
        desc: 'Broadband multi-resonance across 617 MHz to 6000 MHz without costly active switching circuitry or mechanical relays.',
      },
      {
        title: '+92% Data Recognition Distance',
        desc: 'Higher received signal-to-noise ratio (SNR) allows transceivers to lock into high-order modulation schemes at nearly double the physical range.',
      },
      {
        title: '+65% Greater Antenna Gain',
        desc: 'Constructive phase reinforcement focuses isotropic energy towards the horizon rather than wasting it in skyward side-lobes.',
      },
      {
        title: 'Downlink Interference Rejection',
        desc: 'Spatial and multi-layer filtering selectively suppresses adjacent channel jamming and cell tower harmonic cross-talk.',
      },
      {
        title: 'Real-Time Dynamic Optimization',
        desc: 'Algorithmic phase adjustment that stabilizes impedance even when objects, walls, or human hands approach the device.',
      },
    ],
  },

  firmwareDownloads: [
    {
      version: 'v2.4.1 Stable (Latest)',
      releaseDate: 'October 2026',
      device: 'Sky5G™ Router (TCPA-117)',
      notes: 'Enhanced 5G Standalone SA Carrier Aggregation, Wi-Fi 7 Multi-Link Operation (MLO) stability, and AT&T band roaming optimization.',
      fileSize: '48.2 MB',
    },
    {
      version: 'v2.3.8',
      releaseDate: 'July 2026',
      device: 'Sky5G™ Router (TCPA-117)',
      notes: 'T-Priority First Responder QoS prioritization patch, automated APN profile detection, and IPsec tunnel keepalive fix.',
      fileSize: '46.9 MB',
    },
  ],

  frequencyBands: [
    { id: 'b71', name: 'Low Band (n71 / B71)', range: '617 - 698 MHz', designation: 'Rural & Deep Indoor Coverage', useCase: 'T-Mobile extended range 5G, massive geographical reach through forest and walls.', vswr: '< 1.8:1', gainDbi: 3.5 },
    { id: 'b14', name: 'Public Safety (B14 / FirstNet)', range: '758 - 798 MHz', designation: 'T-Priority & FirstNet Emergency', useCase: 'First responder priority bandwidth with guaranteed quality of service.', vswr: '< 1.7:1', gainDbi: 4.2 },
    { id: 'mid', name: 'Mid Band (n41 / n25 / n66)', range: '1710 - 2690 MHz', designation: 'Suburban High-Speed 5G', useCase: 'High capacity carrier aggregation, enterprise primary connectivity.', vswr: '< 1.6:1', gainDbi: 5.0 },
    { id: 'cband', name: 'C-Band & CBRS (n77 / n78)', range: '3300 - 4200 MHz', designation: 'Ultra-Capacity Urban Grid', useCase: 'Gigabit-speed fixed wireless access for enterprise campuses and dense urban centers.', vswr: '< 1.9:1', gainDbi: 6.0 },
    { id: 'wifi7', name: 'Wi-Fi 7 Sub-6 (Unlicensed)', range: '5150 - 5925 MHz', designation: 'Local High-Throughput Fabric', useCase: 'Low latency links for VR, 4K multi-stream cameras, and autonomous robotics.', vswr: '< 1.8:1', gainDbi: 5.8 },
  ] as FrequencyBand[],

  solutions: [
    {
      id: 'first-responders',
      title: 'First Responders & Tactical Defense',
      tagline: 'Certified T-Priority & FirstNet Resilient Communications',
      description: 'When cell towers are damaged or emergency convoys enter radio dead zones, SkyMirr hardware maintains stable mission-critical voice, video telemetry, and GPS data.',
      metrics: ['100% T-Priority Certified', 'Zero Packet Drop at Cell Edge', 'Sub-2ms Wi-Fi 7 Vehicle Area Network'],
      icon: 'ShieldCheck',
    },
    {
      id: 'rural-fwa',
      title: 'Rural Fixed Wireless & Digital Equity',
      tagline: 'Bridging the Connectivity Divide without Trenching Fiber',
      description: 'Deliver true fiber-like broadband to rural communities and agricultural hubs located miles beyond standard cell tower coverage radii using Sky5G’s 42% extended range.',
      metrics: ['+42% Farther Tower Reach', '2x Sustained Speed in Fringe Zones', 'Easy DIY Setup & High Gain Antennas'],
      icon: 'Radio',
    },
    {
      id: 'enterprise-sdwan',
      title: 'Enterprise Branch & SD-WAN Failover',
      tagline: 'Zero-Downtime High-Capacity Primary & Backup Wireless',
      description: 'Keep retail registers, branch office VoIP, and financial transactions running seamlessly with automated carrier-redundant cellular failover and multi-gigabit throughput.',
      metrics: ['Sub-Second Carrier Switchover', '512 Concurrent Devices Supported', 'Enterprise IPsec / WireGuard Tunneling'],
      icon: 'Network',
    },
    {
      id: 'industrial-iot',
      title: 'Industrial IoT & Smart Infrastructure',
      tagline: 'Electromagnetically Hardened for Harsh Environments',
      description: 'Connect distributed solar fields, water treatment plants, autonomous port cranes, and smart transit corridors where electrical noise degrades ordinary wireless devices.',
      metrics: ['Superior Downlink Rejection', 'IP67 Ruggedized Enclosure Options', 'Operating Temp: -40°C to +85°C'],
      icon: 'Cpu',
    },
  ] as Solution[],

  labInfo: {
    location: 'Incheon, South Korea',
    facility: 'Songdo 3D RF Anechoic Chamber & Advanced Measurement Suite',
    description: 'Our state-of-the-art Incheon R&D center houses a calibrated full-anechoic microwave chamber equipped with multi-axis automated positioning turntables, vector network analyzers up to 50 GHz, and active 3D beamforming characterization.',
    capabilities: [
      'Full 3D Spherical Radiation Pattern Characterization',
      'Over-The-Air (OTA) TRP & TIS Measurement for 5G NR',
      'High-Temperature and Moisture Environmental Stress Simulation',
      'Electromagnetic Near-Field Scanner for Multi-Layer Coupling Verification',
    ],
  },

  news: [
    {
      id: 'att-cert',
      date: 'September 2026',
      title: 'SkyMirr Sky5G Router Achieves AT&T Network Certification',
      publication: 'Business Wire & Telecom Insights',
      summary: 'Expanding carrier choice for reliable connectivity, the Sky5G router successfully passes AT&T certification across nationwide sub-6 5G and LTE bands.',
      badge: 'Carrier Certification',
    },
    {
      id: 'antenna-expand',
      date: 'August 2026',
      title: 'SkyMirr Expands Its Antenna Portfolio with New High-Performance 4G/5G and Wi-Fi Solutions',
      publication: 'Microwave Journal',
      summary: 'Unveiling new MIMO modules, dual-polarization vehicle arrays, and Wi-Fi 7 omnidirectional whips powered by patented MuLCAT® architecture.',
      badge: 'Product Launch',
    },
    {
      id: 'ces-2026',
      date: 'January 2026',
      title: 'SkyMirr Sky5G™ Router Named CES® 2026 Innovation Awards Honoree',
      publication: 'Consumer Technology Association',
      summary: 'Honored in the Mobile Devices, Accessories & Apps category for bringing antenna-first physics and Wi-Fi 7 to commercial 5G customer premises equipment.',
      badge: 'Award Recognition',
    },
    {
      id: 'rf-layer',
      date: 'November 2025',
      title: 'Antenna-First Design: Why Real-World 5G Performance Starts at the RF Layer',
      publication: 'SkyMirr Technical Whitepaper',
      summary: 'An engineering treatise on why modern multi-gigabit modems cannot overcome physics if the electromagnetic antenna system lacks sufficient isolation.',
      badge: 'Whitepaper',
    },
  ] as NewsItem[],

  heroSlides: [
    {
      id: 'slide-1',
      image: '/images/slider1.jpg',
      tagline: 'ANTENNA-FIRST WIRELESS',
      title: 'SIGNAL WITHOUT LIMITS',
      description: 'We develop and manufacture advanced RF technology-based products that better connect the world, such as cost-effective better-performing broadband wireless for everyone.',
      ctaText: 'How do we do that?',
      ctaLink: '#technology',
      badge: 'Patented MuLCAT® Technology',
    },
    {
      id: 'slide-2',
      image: '/images/slider2.jpg',
      tagline: 'MISSION-CRITICAL CONNECTIVITY',
      title: 'WHEN IT HAS TO CONNECT, IT HAS TO BE SKYMIRR',
      description: 'We develop/manufacture advanced RF technology-based products that better our lives, such as cost-effective, better performing, broadband wireless communications for everyone and medical applications that treat serious disease far more effectively.',
      ctaText: 'Explore Technology',
      ctaLink: '#technology',
      badge: 'Up to 42% Farther Reach',
    },
    {
      id: 'slide-3',
      image: '/images/skymirr-next-gen-antennas.jpg',
      tagline: 'NEXT-GENERATION 5G & WI-FI 7',
      title: 'NEXT GENERATION ANTENNAS',
      description: 'Powered by MuLCAT® Technology — Ultra-wideband omnidirectional 4G/5G, Sub-6 GHz, C-Band, and Wi-Fi 7 solutions engineered from the electromagnetic field outward.',
      ctaText: 'View Product Portfolio',
      ctaLink: '#products-grid',
      badge: 'CES® 2026 Innovation Honoree',
    },
  ],

  customerSuccess: {
    badge: 'Customer Success Scenario',
    title: 'Retail Expansion Without Connectivity Delays',
    client: 'National Multi-Location Retail Chain',
    challenge: 'A national retailer was opening ten new locations. Fiber installation delays threatened store launches, POS deployment, inventory synchronization, and staff onboarding.',
    solution: 'The retailer implemented Sky5G Routers as primary broadband gateways. Mesh Networking extended coverage across sales floors and warehouses, while MuLCAT® technology maintained stable connectivity through concrete and metal structures.',
    result: 'All 10 stores launched on schedule with zero retail downtime, processing thousands of POS transactions per day with full failover redundancy.',
    metrics: [
      { label: 'Stores Launched', value: '10 / 10' },
      { label: 'Retail Downtime', value: '0 Hours' },
      { label: 'Carrier Redundancy', value: '100% Dual-SIM' },
    ],
  },
};
