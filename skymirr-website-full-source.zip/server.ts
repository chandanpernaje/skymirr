import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { generateRfRecommendation, askRfEngineer } from './src/server/geminiService';

dotenv.config();

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json());

// Server-side Gemini AI endpoints
app.post('/api/gemini/advisor', async (req, res) => {
  try {
    const { scenario } = req.body;
    if (!scenario) {
      return res.status(400).json({ error: 'Scenario description is required' });
    }
    const result = await generateRfRecommendation(scenario);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error running AI RF advisor' });
  }
});

app.post('/api/gemini/chat', async (req, res) => {
  try {
    const { question, history } = req.body;
    if (!question) {
      return res.status(400).json({ error: 'Question is required' });
    }
    const answer = await askRfEngineer(question, history || []);
    res.json({ answer });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Error processing AI chat' });
  }
});

// Serve static assets from dist in production
const distPath = path.resolve(__dirname, 'dist');
app.use(express.static(distPath));

app.get('*', (req, res) => {
  res.sendFile(path.join(distPath, 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`SkyMirr Server running on http://0.0.0.0:${PORT}`);
});
